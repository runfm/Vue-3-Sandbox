import {render} from "@testing-library/vue"

import BaseButton from "./index.vue"

test("renders base button", ()=>{
	const {debug} =  render(BaseButton)

	debug();
})