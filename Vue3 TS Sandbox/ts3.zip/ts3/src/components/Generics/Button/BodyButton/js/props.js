export default {
    active: Boolean,
    borderless: Boolean,
    blank: Boolean,
    disabled: Boolean,
    plain: Boolean,
    tooltip: String,
    icon: String,
    href: String,
    type: {
        type: String,
        default: "default"
    },
    menu: Object,
    family: {
        type: String,
        default: "material" /* element, material, awesome */
    },
    size: {
        type: String,
        default: "medium" /* large, medium, small, mini */
    }
};
//# sourceMappingURL=props.js.map