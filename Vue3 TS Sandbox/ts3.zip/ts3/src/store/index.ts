import { createStore } from 'vuex'

function createUrl(controller: string, method: string, withHost:boolean = false) {
  let base = process.env.BASE_URL
  let url = `${base}api/${controller}/${method}`
  if(withHost){
    let host = window.location.host;
    url = host + "/" + url
  }
  url = url.replaceAll(/\/{2,}/gmi, "/")

  return url
}

export default createStore({
  state: {
    buttonTypes__: null,
    loading: false
  },
  getters: {
    buttonTypes(state, getters) {
      return state.buttonTypes__
    }
  },
  mutations: {
    buttonTypes(state, data) {
      state.buttonTypes__ = data
    }
  },
  actions: {
    async getButtonTypes({ commit, state, getters }) {
      if (state.buttonTypes__ == null) {
        var url = createUrl("newform", "app/data")
        let data = await (await fetch(url)).json()
        commit("buttonTypes", data.ButtonTypes)
      }

      return getters.buttonTypes
    },
    checkWs({ commit, state, getters }){
      var url = createUrl("newform", "ws_close")
      fetch(url)
    },
    ws({ commit, state, getters }) {
      var url = createUrl("newform", "ws_test", true)
      let socket = new WebSocket(`wss://${url}`);
      socket.onopen = function (e) {
        socket.send("Меня зовут Джон");
      };

      socket.onmessage = function(event) {
        console.log(`[message] Данные получены с сервера: ${event.data}`);
      };

      socket.onclose = function(event) {
        if (event.wasClean) {
          console.log(`[close] Соединение закрыто чисто, код=${event.code} причина=${event.reason}`);
        } else {
          // например, сервер убил процесс или сеть недоступна
          // обычно в этом случае event.code 1006
          console.log('[close] Соединение прервано');
        }
      };
      
      socket.onerror = function(error:any) {
        console.log(`[error] ${error.message}`);
      };

      return socket
    }
  },
  modules: {
  }
})
