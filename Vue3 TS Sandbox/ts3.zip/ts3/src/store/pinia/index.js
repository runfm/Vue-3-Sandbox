import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
function createUrl(controller, method, withHost = false) {
    let base = process.env.BASE_URL;
    let url = `${base}api/${controller}/${method}`;
    if (withHost) {
        let host = window.location.host;
        url = host + "/" + url;
    }
    url = url.replaceAll(/\/{2,}/gmi, "/");
    return url;
}
export const useStore = defineStore('counter', () => {
    let sync = ref(false);
    let buttonTypes__ = ref([]);
    //let contextMenu__ = reactive()
    let loading = ref(false);
    const buttonTypes = computed(() => buttonTypes__.value);
    async function getButtonTypes() {
        console.log(buttonTypes__);
        if (sync.value == false) {
            var url = createUrl("newform", "app/data");
            let data = await (await fetch(url)).json();
            buttonTypes__.value = data.ButtonTypes;
            sync.value = true;
        }
        return buttonTypes;
    }
    return { loading, buttonTypes, getButtonTypes };
});
//# sourceMappingURL=index.js.map