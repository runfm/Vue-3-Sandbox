
import { defineStore } from 'pinia'

function createUrl(controller, method, withHost = false) {
	let base = process.env.BASE_URL
	let url = `${base}api/${controller}/${method}`
	if (withHost) {
		let host = window.location.host;
		url = host + "/" + url
	}
	url = url.replaceAll(/\/{2,}/gmi, "/")

	return url
}

export const useStoreX = defineStore('storeId', {
  // arrow function recommended for full type inference
  state: () => {
    return {
      // all these properties will have their type inferred automatically
      counter: 0,
      name: 'Eduardo',
      isAdmin: true,
    }
  },
})