<template lang="pug">
pre.
  Using regular tags can help keep your lines short,
  but interpolated tags may be easier to 
  whether the tags and text are whitespace-separated.
</template>